-- TASK 2
-- CREAZIONE DEL DATABASE
DROP DATABASE IF EXISTS VenditeDB;
CREATE DATABASE VenditeDB;
USE VenditeDB;

-- 1. Tabella delle regioni
CREATE TABLE Regione (
    id_regione INT PRIMARY KEY AUTO_INCREMENT,
    nome_regione VARCHAR(100) NOT NULL
);

-- 2. Tabella degli stati
CREATE TABLE Stato (
    id_stato INT PRIMARY KEY AUTO_INCREMENT,
    nome_stato VARCHAR(100) NOT NULL,
    id_regione INT NOT NULL,
    FOREIGN KEY (id_regione) REFERENCES Regione(id_regione)
);

-- 3. Tabella delle categorie di prodotto
CREATE TABLE CategoriaProdotto (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nome_categoria VARCHAR(100) NOT NULL
);

-- 4. Tabella dei prodotti
CREATE TABLE Prodotto (
    id_prodotto INT PRIMARY KEY AUTO_INCREMENT,
    nome_prodotto VARCHAR(100) NOT NULL,
    prezzo_unitario DECIMAL(10,2) NOT NULL,
    id_categoria INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES CategoriaProdotto(id_categoria)
);

-- 5. Tabella delle vendite
CREATE TABLE Vendita (
    id_vendita INT PRIMARY KEY AUTO_INCREMENT,
    data_vendita DATE NOT NULL,
    quantita INT NOT NULL,
    id_prodotto INT NOT NULL,
    id_stato INT NOT NULL,
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto),
    FOREIGN KEY (id_stato) REFERENCES Stato(id_stato)
);

-- TASK 3
-- POPOLAMENTO DELLE TABELLE
INSERT INTO Regione (nome_regione) VALUES
('South Europe'),
('West Europe');

INSERT INTO Stato (nome_stato, id_regione) VALUES
('Italia', 1),
('Spagna', 1),
('Francia', 2),
('Germania', 2);

INSERT INTO CategoriaProdotto (nome_categoria) VALUES
('Bikes'),
('Clothing'),
('Accessories');

INSERT INTO Prodotto (nome_prodotto, prezzo_unitario, id_categoria) VALUES
('Mountain Bike X100',799.99,1),
('City Bike Comfort',349.50,1),
('Bike Jersey Red',59.90,2),
('Helmet ProSafe',90,3); 
INSERT INTO Prodotto (nome_prodotto, prezzo_unitario, id_categoria)
VALUES ('Kit Pulizia Catena',19.90,3);


INSERT INTO Vendita (data_vendita, quantita, id_prodotto, id_stato) VALUES
('2025-04-01', 5, 1, 1),
('2025-04-01', 3, 2, 2),
('2025-04-02', 2, 3, 3),
('2025-04-02', 4, 4, 1),
('2025-04-03', 1, 1, 4);

-- TASK 4
-- 1) Verifica dell'unicità delle chiavi primarie
-- IDEA: Le chiavi primarie devono essere uniche. Se ci sono due righe con lo stesso ID, abbiamo un duplicato.
-- PROCEDURA: Raggruppo per ID e conto quante volte compare ogni ID. Se un ID compare più di 1 volta, è un errore.
SELECT id_regione, COUNT(*) AS occorrenze FROM Regione GROUP BY id_regione HAVING COUNT(*) > 1;
SELECT id_stato, COUNT(*) AS occorrenze FROM Stato GROUP BY id_stato HAVING COUNT(*) > 1;
SELECT id_categoria, COUNT(*) AS occorrenze FROM CategoriaProdotto GROUP BY id_categoria HAVING COUNT(*) > 1;
SELECT id_prodotto, COUNT(*) AS occorrenze FROM Prodotto GROUP BY id_prodotto HAVING COUNT(*) > 1;
SELECT id_vendita, COUNT(*) AS occorrenze FROM Vendita GROUP BY id_vendita HAVING COUNT(*) > 1;

-- 2) Controllo se sono passati più di 180 giorni da ogni vendita
-- IDEA: Voglio capire se una vendita è “vecchia” rispetto ad oggi.
-- PROCEDURA: Calcolo la differenza in giorni tra oggi e la data della vendita, se è > 180 allora è “vecchia”.
-- In più, mostro info su prodotto, categoria, stato e regione.
SELECT 
  v.id_vendita AS codice_documento,
  v.data_vendita,
  p.nome_prodotto,
  cp.nome_categoria,
  s.nome_stato,
  r.nome_regione,
  CASE 
    WHEN DATEDIFF(CURRENT_DATE(), v.data_vendita) > 180 THEN 'true'
    ELSE 'false'
  END AS oltre_180_giorni
FROM Vendita v
JOIN Prodotto p ON v.id_prodotto = p.id_prodotto
JOIN CategoriaProdotto cp ON p.id_categoria = cp.id_categoria
JOIN Stato s ON v.id_stato = s.id_stato
JOIN Regione r ON s.id_regione = r.id_regione;

-- 3) Prodotti che hanno venduto più della media dell’ultimo anno
-- IDEA: Voglio trovare i prodotti che hanno venduto più della media.
-- PROCEDURA:
--   1. Calcolo la somma delle vendite per ogni anno.
--   2. Scopro qual è l’anno più recente.
--   3. Sommo le quantità vendute per prodotto solo in quell’anno.
--   4. Calcolo la media delle vendite tra tutti i prodotti.
--   5. Mostro solo i prodotti che stanno sopra la media.
WITH TotaleAnnuale AS (
  SELECT YEAR(data_vendita) AS anno, SUM(quantita) AS totale_annuale
  FROM Vendita
  GROUP BY YEAR(data_vendita)
),
MediaAnnuale AS (
  SELECT MAX(anno) AS ultimo_anno FROM TotaleAnnuale
),
QuantitaPerProdotto AS (
  SELECT id_prodotto, SUM(quantita) AS totale_venduto
  FROM Vendita
  WHERE YEAR(data_vendita) = (SELECT ultimo_anno FROM MediaAnnuale)
  GROUP BY id_prodotto
),
MediaQuantita AS (
  SELECT AVG(totale_venduto * 1.0) AS media FROM QuantitaPerProdotto
)
SELECT 
  q.id_prodotto,
  q.totale_venduto
FROM QuantitaPerProdotto q
JOIN MediaQuantita m ON q.totale_venduto > m.media;

-- 4) Fatturato totale per prodotto per anno
-- IDEA: Voglio sapere quanto è stato venduto ogni prodotto ogni anno.
-- PROCEDURA: Raggruppo per anno e prodotto e sommo le quantità vendute.
SELECT 
  p.id_prodotto,
  p.nome_prodotto,
  YEAR(v.data_vendita) AS anno,
  SUM(v.quantita) AS fatturato_totale
FROM Vendita v
JOIN Prodotto p ON v.id_prodotto = p.id_prodotto
GROUP BY p.id_prodotto, p.nome_prodotto, YEAR(v.data_vendita);

-- 5) Fatturato in euro per ogni prodotto per anno
-- IDEA: Voglio sapere quanto ha incassato ogni prodotto ogni anno.
-- PROCEDURA: Moltiplico quantità per prezzo per ogni riga, poi sommo per prodotto e anno.
SELECT 
  p.id_prodotto,
  p.nome_prodotto,
  YEAR(v.data_vendita) AS anno,
  SUM(v.quantita * p.prezzo_unitario) AS fatturato_totale
FROM Vendita v
JOIN Prodotto p ON v.id_prodotto = p.id_prodotto
GROUP BY p.id_prodotto, p.nome_prodotto, YEAR(v.data_vendita)
ORDER BY anno, fatturato_totale DESC;

-- 6) Categoria più venduta in assoluto
-- IDEA: Voglio sapere quale categoria ha venduto più pezzi in totale.
-- PROCEDURA: Raggruppo per categoria e sommo tutte le quantità, poi prendo solo la prima (LIMIT 1).
SELECT cp.nome_categoria, SUM(v.quantita) AS totale_venduto
FROM Vendita v
JOIN Prodotto p ON v.id_prodotto = p.id_prodotto
JOIN CategoriaProdotto cp ON p.id_categoria = cp.id_categoria
GROUP BY cp.nome_categoria
ORDER BY totale_venduto DESC
LIMIT 1;

-- 7) Prodotti mai venduti
-- IDEA: Voglio scoprire se ci sono prodotti inseriti nel catalogo ma mai venduti.
-- PROCEDURA: Se il prodotto non compare nella tabella delle vendite, è invenduto.

-- Primo metodo: uso NOT IN
SELECT * FROM Prodotto
WHERE id_prodotto NOT IN (SELECT DISTINCT id_prodotto FROM Vendita);

-- Secondo metodo: uso LEFT JOIN e cerco righe senza corrispondenza
SELECT p.*
FROM Prodotto p
LEFT JOIN Vendita v ON p.id_prodotto = v.id_prodotto
WHERE v.id_vendita IS NULL;

-- 8) Vista per mostrare prodotti con il nome della categoria
-- IDEA: Voglio creare una vista che unisce prodotto e categoria in una tabella sola.
-- PROCEDURA: Uso una JOIN e creo una VIEW.
CREATE OR REPLACE VIEW vw_ProdottiDenormalizzati AS
SELECT 
  p.id_prodotto,
  p.nome_prodotto,
  cp.nome_categoria
FROM Prodotto p
JOIN CategoriaProdotto cp ON p.id_categoria = cp.id_categoria;

-- 9) Vista con info geografiche (stato e regione)
-- IDEA: Mi serve una vista con info geografiche già pronte.
-- PROCEDURA: Creo una VIEW che unisce Stato e Regione per evitare di rifare la JOIN ogni volta.
CREATE OR REPLACE VIEW vw_InfoGeografiche AS
SELECT 
  s.id_stato,
  s.nome_stato,
  r.nome_regione
FROM Stato s
JOIN Regione r ON s.id_regione = r.id_regione;
